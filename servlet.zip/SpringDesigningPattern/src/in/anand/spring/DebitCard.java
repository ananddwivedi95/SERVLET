package in.anand.spring;

public class DebitCard {

	public boolean payBill(Double bill)
	{
		System.out.println("paying bill using DebitCard"+bill);;
		return true;
	}

}
