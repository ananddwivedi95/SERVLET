package in.anand.spring;

public class PaymentProcess {
	public static void main(String[] args) {
		System.out.println("hello anand");
	}
}
