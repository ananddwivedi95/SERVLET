package in.anand.spring;

public class AmexCard {
	public boolean payBill(Double bill)
	{
		System.out.println("paying bill using AmexCard"+bill);;
		return true;
	}
}
