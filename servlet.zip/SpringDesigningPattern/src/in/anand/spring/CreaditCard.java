package in.anand.spring;

public class CreaditCard {

	public boolean payBill(Double bill)
	{
		System.out.println("paying bill using CradtitCard"+bill);;
		return true;
	}

}
