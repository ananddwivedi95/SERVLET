package in.anand.cookies;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/test")
public class Servlet1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");

        if (name != null && !name.trim().isEmpty()) {
            Cookie nameCookie = new Cookie("userName", name);
            nameCookie.setMaxAge(60 * 5); // 5 minutes expiration
            response.addCookie(nameCookie);
            response.sendRedirect("home.html");
        } else {
            response.sendRedirect("index.html"); // Redirect back if name is empty
        }
    }
}
